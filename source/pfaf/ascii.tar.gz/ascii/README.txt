This archive contains the Plants For A Future Species Database (c) 2003 in text
form. 



The archive contains 10 files:

	Species.txt		The main database with most of the information about
				the plants.

	compo.txt		Composition of Plants

	cultivars.txt	Notes on particular cultivars

	locations.txt	Locations where the plant may grow

	range.txt		Details of the geographical range where the plant can be found

	edib.txt		Index of edible uses

	medic.txt		Index of medical uses

	other.txt		Index of other uses

	edterms.txt		Terms used to describe the edible uses

	medterms.txt	Terms used to describe the medicinal uses

	othterms.txt	Terms used to describe the other uses

	scent.txt		Details of the scent of plants

	synonyms.txt	Synonyms

on the CDROM there are two other tables

	spectab.txt		As Species.txt but just tab diliminated

	culttab.txt		As cultivars.txt but tab deliminated

Details of Table Format
-----------------------

The first line in each file gives the field names for that file.
For most of the tables each record appears on one line and the | character
is used to seperate the fields. For example the first record in Location.txt
is

Abelia triflora|||Dry scrub and rocky slopes in calcareous soils, 1200 - 4200 me
tres in Uttar Pradesh[146, 158].|SN|Shrub|3.5|3|1|0|0|1|0|0|0|1|1|0|0|0|0|0|0|0|
0|||||6

The species.txt and cultivars.txt files are special. They contain memo
fields which can contain newlines in the middle of some of the record. 
This can cause a lot of problems. To get around this the ^ character is used
to deliminate the text fields. 
The files are saved with , seperating each field and " are placed around text
fields. For example the first entry in the cultivars file is

^Abelmoschus esculentus^|^'Annie Oakley'^|^The slender, five-angled pods are lig
ht green in colour and 18 - 22cm long[183]. They are spineless and remain tender
 as they grow to a large size[183].
An F1 hybrid, it ripens earlier than open-pollinated cultivars and can therefore
 succeed in cooler climates, though it is still more suited to protected cultiva
tion in Britain[183, K]. The plants are compact, uniform and heavy yielding, rea
ching a height of about 1 metre[183]. A harvest can be produced within 45 days f
rom sowing the seed[183].^||0|0|10/22/96 0:00:00

Note the newlines in the middle of the third field. 

I've used ^ and | as seperators instead of  the more traditional " and , as 
these occur in some of the records, which would make things difficult for 
parsing using perl. If you need to change things the more traditional form you
can do a global replace in a standard text editor like wordpad or edit.

Perl hacks might like to use script parse.pl to parse the records use

 	parse.pl 55 < species.txt	for species.txt
	parse.pl 7  < cultivar.txt	for the cultivar.txt
by default this puts ( ) round each field and removes the internal
newline characters. Edit the script to change the behaviour.

The CDROM version also contains spectab.txt and culttab.txt which are
versions of the species.txt and cultivars.txt files with tab as fields
separators, no deliminators and the internal newlines in fields removed
so that there is one record on each field.

Importing into SQL
------------------

There are now two scripts to make it easier to import the table into
SQL, the first import1.sql creates the tables and the second
import2.sql actually imports the data.

Fields used in the Species Database
-----------------------------------

Latin name.
     The botanical name of the plant. This is an indexed field and is the
     primary key.
Common name.
     One common name (where available) for the plant. It does not list the
     wide range of common names that many plants have.
Family.
     The family that the plant belongs to. An indexed field.
Author
     The person(s) who named the plant.
Botanical references
     A bibliography of the most relevant books (usually a flora) that
     contain a botanical description of the plant.
Synonyms.
     Other botanical names the plant has been known by. Sometimes there is
     disagreement amongst the botanists as to which is the correct name to
     use. Search's for Latin names will also check the synonyms.
Known hazards.
     Any records we have of toxicity or other harmful aspects of the plant.
Range.
     The regions of the world where the plant grows wild. One limit to this
     field (22/01/93) is that if the plant is native to Britain I haven't
     put down the other areas in which it grows. This will be changed as
     time permits. There is also a table listing the continents the plant
     grows. In the web version a table has been created listing general
     areas where the plant grows, this has been done by just searching for
     particular strings in this field, you can see the possible areas here.
Habitat.
     A description of the habitat where the plant grows wild.
Habit.
     Type of plant. (Annual, perennial, tree etc). An indexed field.
Evergreen/Deciduous
     Whether the plant is deciduous or evergreen. This applies mainly to
     trees and shrubs but is also used when we know that any other type of
     plant is evergreen. D = deciduous, E = evergreen.
Rating:
     A value from 1 to 5. 1 denotes plants of very minor uses, 2 means
     reasonably useful plants, 3 covers the range of plants that could be
     grown as standard crops, 4 is for very useful plants whilst 5 denotes
     those of great value. A very subjective evaluation.
Medicinal Rating
     The rating for medicinal use 5 is best, 1 is worst 0 is no medicinal use
Height.
     How tall the plant is expected to grow in Britain, in meters.
Width.
     How wide the plant is expected to grow, in meters. This field is
     rather lacking in information.
Hardyness.
     How hardy is it on a scale from 1 - 10. One will survive arctic
     winters, ten is tropical. Cornwall is about eight, but can grow some
     plants from zone nine. Most of Britain is zone seven, going down to
     zone six in the north and four in the mountains. An indexed field.
Growth rate.
     How fast the plant can grow. F = fast, M = medium, S = slow. This
     applies mainly to trees and shrubs but a lot of entries are blank
     because we just do not have the information.
In leaf
     Months of the year that the plant is in leaf. 1 = January, 12 =
     December.
Flowering time.
     What time of the year does the plant flower? Recorded in months, 1 =
     January, 12 = December.
Seed ripe.
     What time of the year does the plant produce ripe seed?. Recorded in
     months, 1 = January, 12 = December.
Scented.
     Is the plant know for its scent.
Flower type.
     H = hermaphrodite (the flower has both male and female organs). M =
     monoecious (individual flowers are either male or female, but both
     sexes can be found on the same plant). D = dioecious (individual
     flowers are either male or female, but only one sex is to be found on
     any one plant so both male and female plants must be grown if seed is
     required)
Self-fertile.
     Can one plant growing on its own produce fertile seed without being
     pollinated by any other plants? Y = Yes, N = No, a blank entry denotes
     that we do not know.
Pollinators.
     How is the plant fertilized? Can be either insects, Lepidoptera (Moths
     & Butterflies), Bats, wind, water, Hand, Self, Apomictic (reproduce by
     seeds formed without sexual fusion), or Cleistogamous
     (self-pollinating without flowers ever opening).
Soil.
     Type of soil the plant prefers. L = light (sandy), M = medium (loam),
     H = heavy (clay). An entry here does not specifically mean that a
     plant will tolerate the extremes of very heavy or very sandy soils,
     for further details on this refer to the next two fields. An indexed
     field.
Well-drained.
     Does the plant require a well-drained soil? Many plants cannot
     tolerate soils if the water does not drain away fairly quickly. A
     well-drained soil is usually light or medium, but this is not always
     the case and some light soils are very poorly drained.
Heavy clay.
     Can the plant grow in heavy clay soils?
Poor soil.
     Can the plant grow in nutritionally poor soils?
pH.
     Type of soil the plant prefers. A = acid, N = neutral, B = basic
     (alkaline). An entry here does not necessarily mean that a plant can
     tolerate the extremes of acidity or alkalinity. For further
     information, use the next two fields. An indexed field.
Acid.
     Can the plant grow in very acid soils?
Alkaline.
     Can the plant grow in very alkaline soils?
Saline.
     Can the plant grow in saline soils.
Shade.
     How much shade does the plant need? F = full shade (deep woodland, a
     north-facing wall etc), S = semi-shade (light woodland, a position
     that is shaded for part of the day etc), N = no shade.
Moisture.
     What sort of moisture levels does the plant require? D = dry, M =
     moist (this is the average soil type and does not mean a wet soil), We
     = wet (or boggy), Wa = water (grows in ponds etc).
Wind.
     How wind resistant is the plant? M = tolerates maritime exposure, W =
     tolerates strong winds but not maritime exposure, N = not wind
     tolerant. A blank entry denotes that we have no information.
     Information is somewhat lacking and what we have is mainly related to
     trees and shrubs.
Drought.
     Can an established plant tolerate drought ?
Nitrogen fixer
     Does the plant fix nitrogen from the atmosphere?
Wildlife.
     Is the plant noted for providing food etc for our native wildlife?
Pollution.
     Can the plant tolerate atmospheric pollution? (i.e. can it grow in a
     large town or city, or by a main road?). Y = Yes, N = No, a blank
     entry denotes that we don't know. This question is almost exclusively
     for trees and shrubs since these in general have much more difficulty
     coping with atmospheric pollution.
Frost Tender
     Is the plant frost tender?

Fields with longer textual descriptions

Cultivation details.
     Details on the plant, how to grow it and other relevant information.
Edible uses.
     Details on the edible uses of the plant. See also the list of Edible
     uses.
Medicinal uses
     Details of all the medicinal properties of the plants. We are not
     experts on the medicinal uses of plants and much of the information
     has been taken from other sources. You should talk to someone who
     knows what they are on about before using any of these plants. See
     also the list of Medicinal uses.
Other uses.
     Details on the non-edible uses of the plant. See also the list of
     Other uses.
Propagation.
     Details on how to propagate the plant.

------------------------------------------------------------------------

Please see the web site for a fuller description of each field,

	http://www.comp.leeds.ac.uk/pfaf/D_intro.html



If you need any help or have problems email me (Rich) webmaster@pfaf.org
(note I'm just a humble computer hack who doesn't know much about plants,
I just made this info avaliable). The real credit should go to Ken Fern
and all the others at the main Plants For A Future site: 

	Plants For A Future,
        Blagdon Cross,
        Ashwater,
        Beaworthy,
        Devon, 
	EX21 5DF,
        England
        Telephone 01208 872 963


Copyright and license

This database and supporting literature is 
Copyright (c) 1992-2003 Plants For A Future and Ken Fern.

The database is covered by a Creative Commons: attribution required, 
non-commercial, share-alike license.

This basically means:

    * You are allowed to use it at home or work however you wish.
    * If you wish to redistribute the information in anyway (i.e. 
	factsheets included with plants, or mirroring the database 
	on you website) you must adhere to the the following 
	conditions (see license condition above for precise legal 
	statement):
         1. That you give full attribution to Plants For A Future. 
		On website this means must retain prominent links to 
		Plants for a Future.
         2. It can not be used for commercial purposes. For 
		nurseries herbalists etc you can supply printed info 
		sheets on the plants if you make a donation of at least 
		�100 to the project. If you wish to use the database on 
		a commercial web-site, including advertising driven 
		websites then please contact us for details.
         3. We wish to adhere to OpenSource/ShareAlike principals, 
		where information is accessible to all. For that reason 
		the standard license adopts the share-alike principal 
		and any additions, corrections, representations etc. 
		to the database must be made available under a creative 
		commons license of the same kind. In particular we would 
		appreciate that any information added is shared with us 
		so that we can keep the main data source as up to date 
		as possible.
    * Due of Microsoft license restrictions you may not redistribute 
		the Microsoft Access runtime components (all files in 
		the standalone access version bar the plantuse.mdb file 
		and the documentation).

If you wish to obtain a different license then please email us 
webmaster@pfaf.org us with your requirements and we will be able to 
come to some arrangement.

Plants For A Future is a charitable company limited by guarantee, 
registered in England and Wales.
Charity No. 1057719, Company No. 3204567,
Reg. Office 1 Lerryn View, Lerryn, Lostwithiel, Cornwall, PL22 0QJ.
Trustees: Dr R. J. Morris, S. H. Money 
