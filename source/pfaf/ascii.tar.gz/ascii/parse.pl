#! /use/bin/perl -w

# perl script to parse the records in the species.txt and
# cultivar.txt files. The first argument is the number
# of fields expected.

# This 
# Run it as 
# 	parse.pl 54 < species.txt	for species.txt
#	parse.pl 7  < cultivar.txt	for the cultivars

# This script will print record like (field1)	(field2) ...
# and remove the internal newlines.
# To configure to your own needs change the following
$left = "(";
$right = ")";
$fieldsep = "\t";
$internal = " "; 
# change this to "\n" if you want to keep internal newlines

$numfields = $ARGV[0];

$count = 0; # the number of | encoundered
$bigline = "";
while(<STDIN>)
{
	s/\^//g;
	@thisline = split(/\|/,$_);
	$count = $count + $#thisline;
	#  $#thisline is the number of diliminiters
#	print "$#thisline $count ($_)\n";

	if( $count+1 == $numfields ) 
	{
		# have now read a complete record output
		chomp;
		$bigline .= $_ ;
#		print "BIGLINE ($bigline)\n";

		$bigline =~ s/\n/$internal/sg;
		@fullline = split(/\|/s,$bigline,$numfields);

		for($i=0;$i<$numfields-1;++$i)
		{
			print "$left$fullline[$i]$right$fieldsep";
		}
		print "$left$fullline[$numfields-1]$right\n";
		$count = 0;
		$bigline = "";
	}
	else
	{
		$bigline .= $_;
	}
}

